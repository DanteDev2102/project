from odoo import http
from odoo.http import request


class MyController(http.Controller):
    @http.route("/my_module/send_data", type="json", auth="user", csrf=False)
    def send_data(self, **kw):
        # Procesar los datos recibidos
        session_id = kw.get("session_id")
        # ... otros datos ...

        # Obtener el registro de la sesión
        session = request.env["op.session"].browse(int(session_id))

        # Imprimir los datos por consola
        print(
            "Datos recibidos:", session.name, session.date
        )  # Ajusta según los campos de tu modelo

        return {"result": "OK"}
