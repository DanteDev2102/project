from odoo import models, fields


class SessionWizard(models.TransientModel):
    _name = "op.session.wizard"
    _description = "wizard to create xlsx report"

    session_id = fields.Many2one(
        "op.session",
        required=True,
        default=lambda self: self.env.context.get("active_id"),
    )
