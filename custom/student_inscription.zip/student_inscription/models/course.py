from odoo import models, fields


class OpCourse(models.Model):
    _inherit = "op.course"
    _rec_name = "pnf"
